/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package bookstore;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.application.Application;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


/**
 *
 * @author a34hasan
 */
public class Bookstore extends Application {
        private ArrayList<Book> books;
        private ArrayList<Customer> customers;
        private Owner bookstoreOwner;
        public GridPane paneLogin;
        public Scene scene;
        
    
    
        public Bookstore()
        {
            books=new ArrayList<Book>();
            customers=new ArrayList<Customer>();
            bookstoreOwner=Owner.getInstance();
        }
        public void addBook(Book bookName) {
            books.add(bookName);
            System.out.println(bookName + " added to the store.");
        }
    
        public void removeBook(Book bookName) {
            if (books.remove(bookName)) {
                System.out.println(bookName + " removed from the store.");
            } else {
                System.out.println("Book not found.");
            }
        }
    
        public ArrayList<Book> getBooks() {
            return books;
        }
    
        public void displayBooks() {
            System.out.println("Books available in the store: ");
        }

    @Override
    public void start(Stage primaryStage)
    {
        
        //Loading data
        loadData();
        //Adding buttons for basic login screen and creating login screen layout
        
        
        
        
        
        Button btnLogin=new Button("Login");
        TextField txtUsername=new TextField();
        TextField txtPassword=new TextField();
        Label lblUsername=new Label("Username: ");
        Label lblPassword=new Label("Password");
        Label lblWelcome=new Label("Welcome to the Bookstore App");
        paneLogin=new GridPane();
        paneLogin.add(lblWelcome,0,0, 1, 1);
        paneLogin.add(lblUsername, 0, 1,1,1);
        paneLogin.add(txtUsername,1,1,1,1);
        paneLogin.add(lblPassword,0,2,1,1);
        paneLogin.add(txtPassword,1,2,1,1);
        paneLogin.add(btnLogin,1,3,1,1);
        
        
        
        
        
        
        
        
        
        
        
        
        //Owner Screen with 3 buttons creation
        TilePane ownerScreen=new TilePane();
        Button btnBooks=new Button("Books");
        Button btnCustomers=new Button("Customers");
        Button btnLogout=new Button("Logout");
        btnBooks.setPrefSize(100, 50);
        btnCustomers.setPrefSize(100,50);
        btnLogout.setPrefSize(100,50);
        ownerScreen.getChildren().addAll(btnBooks,btnCustomers,btnLogout);
        ownerScreen.setOrientation(Orientation.VERTICAL);
        ownerScreen.setVgap(25);
        ownerScreen.setAlignment(Pos.CENTER);
        
        //Owner screen layout after clicking customer button
        TableView<Customer> customerTable=new TableView<Customer>();
        customerTable.setEditable(true);
        
        TableColumn<Customer,String> columnUsername=new TableColumn("Username");
        columnUsername.setCellValueFactory(new PropertyValueFactory<Customer,String>("username"));
        
        TableColumn<Customer,String> columnPassword=new TableColumn("Password");
        columnPassword.setCellValueFactory(new PropertyValueFactory<Customer,String>("password"));
        
        TableColumn<Customer,String> columnPoints=new TableColumn("Points");
        columnPoints.setCellValueFactory(new PropertyValueFactory<Customer,String>("points"));
        
        customerTable.getColumns().addAll(columnUsername,columnPassword,columnPoints);
        ObservableList<Customer> customerInfo=FXCollections.observableArrayList(customers);
        customerTable.setItems(customerInfo);
        
        //VBox pane for owner customer screen
        VBox ownerCustomerScreen=new VBox();
        FlowPane addCustomer=new FlowPane();
        Label lblUserAdd= new Label("Username: ");
        TextField txtUserAdd=new TextField();
        
        Label lblPassAdd= new Label("Password: ");
        TextField txtPassAdd=new TextField();
        Button btnAddNewCustomer=new Button("Add");
        addCustomer.getChildren().addAll(lblUserAdd,txtUserAdd,lblPassAdd,txtPassAdd,btnAddNewCustomer);
        
        FlowPane backAndDelete=new FlowPane();
        Button btnBackOwner=new Button("Back");
        Button btnDeleteCustomer=new Button("Delete");
        backAndDelete.getChildren().addAll(btnBackOwner,btnDeleteCustomer);
        
        ownerCustomerScreen.getChildren().addAll(customerTable,addCustomer,backAndDelete);
        ownerCustomerScreen.setAlignment(Pos.CENTER);
        
        
        
        
        
         scene = new Scene(paneLogin, 400, 400);
        primaryStage.setTitle("Bookstore App");
        primaryStage.setScene(scene); // primaryStage<-------Scene(paneLogin<---root)                         primaryStage< ----Scene(OwnerScreen<----new root)
        
        
        
        
        
        
        //Owner book screen
        TableView<Book> bookTable=new TableView<Book>();
        customerTable.setEditable(true);
        
        TableColumn bookNameOwnerColumn=new TableColumn("Name");
        bookNameOwnerColumn.setCellValueFactory(new PropertyValueFactory<Book,String>("name"));
        
        TableColumn bookPriceOwnerColumn=new TableColumn("Price");
        bookPriceOwnerColumn.setCellValueFactory(new PropertyValueFactory<Book,String>("price"));
        
        
        bookTable.getColumns().addAll(bookNameOwnerColumn,bookPriceOwnerColumn);
        ObservableList<Book> bookInfo=FXCollections.observableArrayList(bookstoreOwner.getBooks());
        bookTable.setItems(bookInfo);
        
        //Add book
        FlowPane addBook=new FlowPane();
        Label lblBookNameAdd=new Label("Name: ");
        TextField txtBookNameAdd=new TextField();
        Label lblBookPriceAdd=new Label("Price: ");
        TextField txtBookPriceAdd=new TextField();
        Button btnBookAdd=new Button("Add");
        addBook.getChildren().addAll(lblBookNameAdd,txtBookNameAdd,lblBookPriceAdd,txtBookPriceAdd,btnBookAdd);
        
        
        //Back and delete book
        FlowPane backAndDeleteBook=new FlowPane();
        Button btnDeleteBook=new Button("Delete");
        Button btnBackOwnerBook=new Button("Back");
        backAndDeleteBook.getChildren().addAll(btnDeleteBook,btnBackOwnerBook);
        
        VBox ownerBookScreen=new VBox();
        ownerBookScreen.getChildren().addAll(bookTable,addBook,backAndDeleteBook);
        
        
        //Login screen button action event handlers
        btnLogin.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event)
            {
                String userGuess=txtUsername.getText();
                String passwordGuess=txtPassword.getText();
                if(userGuess.equals("admin")&&passwordGuess.equals("admin"))
                {
                    scene.setRoot(ownerScreen);
                }
                for(int k=0;k<customers.size();k++)
                {
                    
                    Customer check=customers.get(k);
                    //System.out.println(check.getUsername()+","+check.getPassword());
                    String passCheck=check.getPassword();
                    
                    String userCheck=check.getUsername();
                    if((userGuess.equals(userCheck)) && passwordGuess.equals(passCheck))
                    {
                        System.out.println("Succesful login");
                        primaryStage.setScene(new Scene(customerHomeGridPane(k), 1000, 600));
                    }
                }
            }
        });
        
        //Owner customer Screen buttons
        btnLogout.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event)
            {
                scene.setRoot(paneLogin);
            }
        });
        btnCustomers.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event)
            {
                scene.setRoot(ownerCustomerScreen);
            }
        });
        btnAddNewCustomer.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event)
            {
                String userAdd=txtUserAdd.getText();
                String passAdd=txtPassAdd.getText();
                Customer newCustomer=new Customer("N/A",userAdd,passAdd,0);
                //While the name is specified for opening in another menu, it's not specified here
                bookstoreOwner.addCustomer(newCustomer);
                customers.add(newCustomer);
                customerInfo.add(newCustomer);
                
            }
        });
        btnDeleteCustomer.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event)
            {
                if((customerTable.getSelectionModel().getSelectedItem())!=null)
                {
                    Customer customerRemoved=customerTable.getSelectionModel().getSelectedItem();
                    bookstoreOwner.removeCustomer(customerRemoved);
                    customers.remove(customerRemoved);
                    customerInfo.remove(customerRemoved);
                }
                
            }
        });
        //Back button for owner customer screen
        btnBackOwner.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event)
            {
                scene.setRoot(ownerScreen);
                
            }
        });
        //Back button for owner book screen
        btnBackOwnerBook.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event)
            {
                scene.setRoot(ownerScreen);
                
            }
        });
        //Owner Book Screen
        btnBooks.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event)
            {
                scene.setRoot(ownerBookScreen);
                
            }
        });
        btnBookAdd.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event)
            {
                String nameEntered=txtBookNameAdd.getText();
                String priceEntered=txtBookPriceAdd.getText();
                Scanner scanDouble=new Scanner(priceEntered);
                double priceInput=scanDouble.nextDouble();
                int uniqueBook=-1;
                for(int i=0;i<books.size();i++)
                {
                    Book uniqueCheck=books.get(i);
                    if((uniqueCheck.getName()).equals(nameEntered))
                    {
                        uniqueBook=0;
                    }
                    
                }
                if(uniqueBook==-1)
                {
                    Book addNewBook=new Book(nameEntered,priceInput,"N/A","N/A",1);
                    //Objects listed are specified to only have 1 copy
                    bookstoreOwner.addBook(addNewBook);
                    books.add(addNewBook);
                    bookInfo.add(addNewBook);
                }
                
                
                
            }
        });
        btnDeleteBook.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event)
            {
                if((bookTable.getSelectionModel().getSelectedItem())!=null)
                {
                    Book bookRemoved=bookTable.getSelectionModel().getSelectedItem();
                    bookstoreOwner.removeBook(bookRemoved);
                    for(int i=0;i<books.size();i++)
                    {
                        Book element=books.get(i);
                        if((element.getName()).equals(bookRemoved.getName())&&(element.getPrice())==(bookRemoved.getPrice())&&(element.getAuthor()).equals(bookRemoved.getAuthor())&&(element.getISBN()).equals(bookRemoved.getISBN())&&(element.getStock())==(bookRemoved.getStock()))
                        {
                           books.remove(books.get(i));
                        }
                    }
                    bookInfo.remove(bookRemoved);
                }
                
            }
        });
        
        //Window closing 
        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>(){
            @Override
            public void handle(WindowEvent e)
            {
                saveData();
            }
        });
        
       
        primaryStage.show();
    }
    public VBox customerHomeGridPane(int customerIndex) {
        VBox customerHomeVB = new VBox(); //Uses Vbox layout pane for customer start page
        
        customerHomeVB.setPadding(new Insets(20,0,0,0)); //Spacing of welcome message from top window
        
        //Top part of customer start screen
        Customer currentCustomer = customers.get(customerIndex);
        Label customerGreetLbl = new Label("Welcome " + currentCustomer.getName() + ". You have " + currentCustomer.getPoints() + " points. Your status is " + currentCustomer.getState(currentCustomer.getPoints()) + ".");
        customerHomeVB.setAlignment(Pos.TOP_CENTER); //Alligns to be top center
        
        TableView<Book> table = new TableView<>(); //Creates table
        ObservableList<Book> bookData = FXCollections.observableArrayList();
        
        //Iterates through all book objects in arraylist and adds to the ObservableList
        for (int i = 0; i < books.size(); i++) {
            bookData.add(books.get(i));
        }
        //Book name column
        TableColumn<Book,String> bookNameCol = new TableColumn<>("Book Name");
        bookNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        bookNameCol.setMinWidth(200);
        
        //Book price column
        TableColumn<Book,Double> bookPriceCol = new TableColumn<>("Book Price");
        bookPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        bookPriceCol.setMinWidth(100);
        
        //Check box column
        TableColumn<Book,Boolean> selectionCol = new TableColumn<>("Select");
        selectionCol.setCellValueFactory(cellData -> cellData.getValue().getSelectedBook()); //Links checkbox to the selected object instance of books in book arraylist
        selectionCol.setCellFactory(CheckBoxTableCell.forTableColumn(selectionCol));
        selectionCol.setMinWidth(100);
        
        table.setEditable(true); //Allows checkboxes to be ticked or unticked
        
        table.getColumns().addAll(bookNameCol, bookPriceCol, selectionCol);
        table.setItems(bookData);
        
        //Bottom buttons
        Button buyBtn = new Button("Buy"); 
        Button pointsBuyBtn = new Button("Redeem Points and Buy");
        Button logoutBtn = new Button("Logout");
        
        buyBtn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle (ActionEvent event) {
                Stage stage = (Stage) buyBtn.getScene().getWindow();
                stage.setScene(new Scene(customerCostScreen(customerIndex, false), 1000, 600));
            }
        });
        pointsBuyBtn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle (ActionEvent event) {
                Stage stage = (Stage) pointsBuyBtn.getScene().getWindow();
                stage.setScene(new Scene(customerCostScreen(customerIndex,true), 1000, 600));
            }
        });
        
        //Creates button with HBox layout pane
        HBox buttonBox = new HBox(buyBtn, pointsBuyBtn, logoutBtn);
        buttonBox.setAlignment(Pos.BOTTOM_CENTER); //Places buttons to always be at the bottom of screen
        buttonBox.setSpacing(100); //Distances buttons
        buttonBox.setPadding(new Insets(0,0,20,0)); //Adds spacing from bottom
        
        
        VBox.setMargin(table, new Insets(20, 0, 20, 0));
        
        customerHomeVB.getChildren().addAll(customerGreetLbl, table, buttonBox);
        
        return customerHomeVB;
    }
    public VBox customerCostScreen(int customerIndex, boolean redeemPoints) {
        VBox costScreenVB = new VBox(); //Uses Vbox layout pane for customer cost page
        costScreenVB.setAlignment(Pos.CENTER);
        costScreenVB.setPadding(new Insets(20)); //Equal 20 space on all sides
        costScreenVB.setSpacing(30); //Spacing between GUI elements
        
        
        Customer currentCustomer = customers.get(customerIndex); //Refers to specific arraylist customer element
        ArrayList<Book> selectedBooks = new ArrayList<>();
        double totalCost = 0.0; //Total cost on books
        
        //Iterates through books arraylist
        for (Book book: books) {
            if (book.isSelectedChecker()) { //Sums total cost of books that are selected with the checkboxes
                selectedBooks.add(book);
                totalCost += book.getPrice();
                
            }
        }
        
        if (redeemPoints == true) {
            
            int pointsToRedeem = Math.min(currentCustomer.getPoints(), (int)(totalCost * 100));
            double discount = pointsToRedeem / 100;
            
            totalCost = Math.max(totalCost - discount, 0);
            
            currentCustomer.redeemPoints("Purchase", pointsToRedeem);
            
        }
        
        currentCustomer.buyBook("Purchase", totalCost);
        
        Label totalCostLbl = new Label("Total Cost: $" + String.format("%.2f", totalCost));
        totalCostLbl.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;"); //Increases font size and makes it bold
        totalCostLbl.setAlignment(Pos.CENTER);
        
        Label pointsStatusLbl = new Label("Points: " + currentCustomer.getPoints() + ", Status: " + currentCustomer.getState(currentCustomer.getPoints()));
        pointsStatusLbl.setStyle("-fx-font-size: 20px; -fx-font-weight: bold");
        pointsStatusLbl.setAlignment(Pos.CENTER);
        
        Button logoutBtn = new Button("Logout");
        logoutBtn.setStyle("-fx-font-size: 16px;");
        //ADD CODE FOR LOGOUT BUTTON ACTION HERE!
       logoutBtn.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event)
            {
                
                scene.setRoot(paneLogin);
            }
        });
        
        costScreenVB.getChildren().setAll(totalCostLbl, pointsStatusLbl, logoutBtn);
        return costScreenVB;
    }
    public void login(GridPane pane,Scene scene, Button btn)
    {
        btn.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event)
            {
                scene.setRoot(pane);
                
            }
        });
    }
    
    public void loadData()
    {
        int bookCounter=0;
            int i=0;
            int j=0;
            double price=0;
            int stock=0;
            int points=0;
            System.out.println("loadData() test");
            try {
                
                FileReader bookRecord=new FileReader("books.txt");
                Scanner scan=new Scanner(bookRecord);
                while(scan.hasNextLine())
                {
                    i=0;
                    bookCounter++;
                    String bookLine=scan.nextLine();
                    Scanner bookToken=new Scanner(bookLine);
                    bookToken.useDelimiter(",");
                    String properties[]=new String[5];
                    //Each line is name,price,author,ISBN,stock
                    //Means you always know what value is which 
                    //Make sure to avoid tokenizing ISBN number as integer though or double
                    while(bookToken.hasNext())
                    {
                        if(bookToken.hasNextInt() && i==4) //The way the tokenizer is set up will always ensure that the index of 3 will be an 
                        {
                            stock=bookToken.nextInt();
                        }
                        else if(bookToken.hasNextDouble()&& i==1)
                        {
                            price=bookToken.nextDouble();
                        }
                        else
                        {
                            properties[i]=bookToken.next();
                        }
                        i++;
                    }
                    
                    Book bookAdd=new Book(properties[0],price,properties[2],properties[3],stock);
                    System.out.println(properties[0]+","+price+","+properties[2]+","+properties[3]+","+stock);
                    books.add(bookAdd);
                    Book bookAddOwner=new Book(properties[0],price,properties[2],properties[3],1);
                    bookstoreOwner.addBook(bookAdd);
                    stock=0;
                    price=0;
                }
                bookRecord.close();
                //Completed acquiry of bookstore data
                FileReader customerRecord=new FileReader("customers.txt");
                Scanner scanC=new Scanner(customerRecord);
                while(scanC.hasNextLine())
                {
                    j=0;
                    String customerLine=scanC.nextLine();
                    Scanner customerToken=new Scanner(customerLine);
                    customerToken.useDelimiter(",");
                    String customerProperties[]=new String[4];
                    while(customerToken.hasNext())
                    {
                        if(customerToken.hasNextInt() && j==3)
                        {
                            points=customerToken.nextInt();
                        }
                        else
                        {
                            customerProperties[j]=customerToken.next();
                        }
                        j++;
                    }
                    Customer customerAdd=new Customer(customerProperties[0],customerProperties[1],customerProperties[2],points);
                    System.out.println(customerProperties[0]+","+customerProperties[1]+","+customerProperties[2]+","+points);
                    customers.add(customerAdd);
                    bookstoreOwner.addCustomer(customerAdd);
                    points=0;
                }
                customerRecord.close();
                
                
            } catch (IOException e)
            {
                
            }
    }
    public void saveData()
    {
        try{
        FileWriter bookFile=new FileWriter("books.txt");
        for(int i=0;i<books.size();i++)
        {
            Book bookWrite=books.get(i);
            bookFile.write(bookWrite.getName()+","+bookWrite.getPrice()+","+bookWrite.getAuthor()+","+bookWrite.getISBN()+","+bookWrite.getStock()+"\n");
        }
        bookFile.close();
        FileWriter customerFile=new FileWriter("customers.txt");
        for(int j=0;j<customers.size();j++)
        {
            Customer customerWrite=customers.get(j);
            customerFile.write(customerWrite.getName()+","+customerWrite.getUsername()+","+customerWrite.getPassword()+","+customerWrite.getPoints()+"\n");
        }
        customerFile.close();
        }
        catch(IOException e)
        {
            
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
