/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookstore;

/**
 *
 * @author a34hasan
 */
import java.util.ArrayList;

public abstract class CustomerState {
    protected Customer customer;

    public CustomerState(Customer customer) {
        this.customer = customer;
    }

    public abstract void buyBook(String bookName, double price);
    public abstract void redeemPoints(String bookName, int points);
}