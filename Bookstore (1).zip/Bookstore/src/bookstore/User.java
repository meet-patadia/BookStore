/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookstore;

/**
 *
 * @author a34hasan
 */
public class User
{
    protected String username;
    protected String password;
    public User(String UserU, String passU)
    {
        this.username=UserU;
        this.password=passU;
        
    }
    public String getUsername()
    {
        return this.username;
    }
    public String getPassword()
    {
        return this.password;
    }
    
}
