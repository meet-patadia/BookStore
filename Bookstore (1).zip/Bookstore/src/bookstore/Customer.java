/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookstore;

/**
 *
 * @author a34hasan
 */
import java.util.ArrayList;

public class Customer extends User{
    private String username;
    private String password;
    private String name;
    private int points;
    private CustomerState state;

    public Customer(String name, String username, String password, int points)
    {
        super(username,password);
        this.points = points;
        this.state = (points >= 500) ? new GoldState(this) : new SilverState(this);
        this.name=name;
    }

    public void buyBook(String bookName, double price) {
        state.buyBook(bookName, price);
    }

    public void redeemPoints(String bookName, int points) {
        state.redeemPoints(bookName, points);
    }

    public void setState(CustomerState state) {
        this.state = state;
    }

    public int getPoints() {
        return points;
    }

    public void addPoints(int points) {
        this.points += points;
    }
    public String getName()
    {
        return this.name;
    }
    
     public String getState (int points) {
        if (points < 1000) {
            return "Silver";
        }
        else {
            return "Gold";
        }
    }
     
    public String getUsername() {
        return super.getUsername();
    }
}